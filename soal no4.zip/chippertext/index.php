<!DOCTYPE html>
<html lang="en">
<head>
<title>Aplikasi Chipper Text</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<?php


// function to encrypt the text given
function encrypt($pswd, $text)
{
	// change key to lowercase for simplicity
	$pswd = strtolower($pswd);
	
	// intialize variables
	$code = "";
	$ki = 0;
	$kl = strlen($pswd);
	$length = strlen($text);
	
	// iterate over each line in text
	for ($i = 0; $i < $length; $i++)
	{
		// if the letter is alpha, encrypt it
		if (ctype_alpha($text[$i]))
		{
			// uppercase
			if (ctype_upper($text[$i]))
			{
				$text[$i] = chr(((ord($pswd[$ki]) - ord("a") + ord($text[$i]) - ord("A")) % 26) + ord("A"));
			}
			
			// lowercase
			else
			{
				$text[$i] = chr(((ord($pswd[$ki]) - ord("a") + ord($text[$i]) - ord("a")) % 26) + ord("a"));
			}
			
			// update the index of key
			$ki++;
			if ($ki >= $kl)
			{
				$ki = 0;
			}
		}
	}
	
	// return the encrypted code
	return $text;
}

// function to decrypt the text given
function decrypt($pswd, $text)
{
	// change key to lowercase for simplicity
	$pswd = strtolower($pswd);
	
	// intialize variables
	$code = "";
	$ki = 0;
	$kl = strlen($pswd);
	$length = strlen($text);
	
	// iterate over each line in text
	for ($i = 0; $i < $length; $i++)
	{
		// if the letter is alpha, decrypt it
		if (ctype_alpha($text[$i]))
		{
			// uppercase
			if (ctype_upper($text[$i]))
			{
				$x = (ord($text[$i]) - ord("A")) - (ord($pswd[$ki]) - ord("a"));
				
				if ($x < 0)
				{
					$x += 26;
				}
				
				$x = $x + ord("A");
				
				$text[$i] = chr($x);
			}
			
			// lowercase
			else
			{
				$x = (ord($text[$i]) - ord("a")) - (ord($pswd[$ki]) - ord("a"));
				
				if ($x < 0)
				{
					$x += 26;
				}
				
				$x = $x + ord("a");
				
				$text[$i] = chr($x);
			}
			
			// update the index of key
			$ki++;
			if ($ki >= $kl)
			{
				$ki = 0;
			}
		}
	}
	
	// return the decrypted text
	return $text;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['type']) && $_POST['type']=="enkripsi") {

  $plaintext = $_POST["original_string"];
  $key = $_POST["key"];

  // Enkripsi Base64
  $base64 = base64_encode($plaintext);

  // Enkripsi ROT13
  $rot13 = str_rot13($base64);
  
  // Enkripsi Vigenere Cipher
  $vigenere = encrypt($key,$rot13);
  $hasil_enkripsi = $vigenere;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['type']) && $_POST['type']=="deskripsi") {

  $ciphertext = $_POST["encrypted_string"];
  $key = $_POST["key_des"];

  // Dekripsi Vigenere Cipher
  $vigenere = decrypt($key,$ciphertext);

  // $vigenere = $ciphertext;
  // Dekripsi ROT13
  $rot13 = str_rot13($vigenere);

  // Dekripsi Base64
  $base64 = base64_decode($rot13);


  $hasil_deskripsi = $base64;
  $des = "active";
}
?>
<div class="container">
  
  <div class="row">
    <div class="col-md-12" style='margin-top:100px'>
     
    <ul class="nav nav-pills">
      <li class="active"><a data-toggle="pill" href="#home">Enkripsi & Deskripsi</a></li>
    </ul>

    <div class="tab-content">
      <div id="home" class="tab-pane fade in active">
        <h3>Enkripsi Text</h3>
        <form method="post">
          <label for="original_string">Masukkan Teks Asli:</label>
          <input type="text" id="original_string" value="<?php echo @$_POST['original_string']?>" required name="original_string">
          <br>
          <label for="key">Masukkan Kunci Vigenere:</label>
          <input type="text" id="key" value="<?php echo @$_POST['key']?>" name="key" required>
          <br>
          Hasil : <b><?php echo @$hasil_enkripsi?></b><br><br>
          <input type="hidden" name="type" value="enkripsi">
          <input type="submit" value="Proses Enkripsi">
      </form>

      <br><br>
      <h3>Deskripsi Text</h3>
        <form method="post">
          <label for="encrypted_string">Masukkan Teks Terenkripsi:</label>
          <input type="text" id="encrypted_string" value="<?php echo @$_POST['encrypted_string']?>" required name="encrypted_string">
          <br>
          <label for="key">Masukkan Kunci Vigenere:</label>
          <input type="text" id="key_des" value="<?php echo @$_POST['key_des']?>" required name="key_des"><br>
          Hasil : <b><?php echo @$hasil_deskripsi?></b><br><br>
          <input type="hidden" name="type" value="deskripsi">
          <input type="submit" value="Proses Deskripsi">
        </form>
      </div>
      
    </div>
    </div>
  </div>
</div>

</body>
</html>